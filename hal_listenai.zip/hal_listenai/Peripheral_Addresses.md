# Peripheral Base Addresses - Listenai CSK6 Venus SoC

*Generated from codebase analysis on 2025-01-21*

## CORTEX-M33 (AP) MEMORY MAP

### System Memory Regions

| Address | Size | Description |
|---------|------|-------------|
| `0x00000000` | 64KB | ROM_BASE - Boot ROM |
| `0x00010000` | 12KB | ITCM_BASE - Instruction Tightly Coupled Memory |
| `0x00080000` | 384KB | CODE_RAM_BASE - Code RAM + System RAM |
| `0x18000000` | 8MB | IFLASH_BASE - Instruction Flash (max 128MB) |
| `0x20000000` | 12KB | DTCM_BASE - Data Tightly Coupled Memory |
| `0x20080000` | 384KB | SYS_RAM_BASE - System RAM |
| `0x28000000` | 640KB | SHMEM_BASE - Shared Memory (CM33 ↔ HiFi4) |
| `0x30000000` | 8MB | PSRAM_BASE - External PSRAM (max 128MB) |
| `0x38000000` | 8MB | FLASH_BASE - External Flash (max 128MB) |

### High-Speed Peripherals

| Address | Size | Description |
|---------|------|-------------|
| `0x40000000` | 16MB | DMAC_BASE - DMA Controller |
| `0x41000000` | 16MB | USBC_BASE - USB Controller |
| `0x42000000` | 16MB | SDIO_BASE - SDIO/SD Card Controller |

### Security & System Control

| Address | Size | Description |
|---------|------|-------------|
| `0x44000000` | 1MB | EFUSE_CTRL_BASE - eFuse Controller |
| `0x44100000` | 1MB | TIMER_BASE - Dual Timer |
| `0x44200000` | 1MB | WDT_BASE - Watchdog Timer |
| `0x44300000` | 1MB | CRYPTO_BASE - Cryptographic Engine |

### Communication Interfaces

| Address | Size | Description |
|---------|------|-------------|
| `0x45000000` | 1MB | UART0_BASE - UART Channel 0 |
| `0x45100000` | 1MB | UART1_BASE - UART Channel 1 |
| `0x45200000` | 1MB | UART2_BASE - UART Channel 2 |
| `0x45300000` | 1MB | IR_BASE - Infrared Controller |
| `0x45400000` | 1MB | SPI0_BASE - SPI Channel 0 |
| `0x45500000` | 1MB | SPI1_BASE - SPI Channel 1 |
| `0x45600000` | 1MB | I2C0_BASE - I2C Channel 0 |
| `0x45700000` | 1MB | I2C1_BASE - I2C Channel 1 |

### Timing & GPIO

| Address | Size | Description |
|---------|------|-------------|
| `0x45800000` | 1MB | GPT_BASE - General Purpose Timer |
| `0x45900000` | 1MB | GPIO0_BASE - GPIO Port A |
| `0x45A00000` | 1MB | GPIO1_BASE - GPIO Port B |
| `0x45B00000` | 1MB | GPADC_BASE - General Purpose ADC |
| `0x45C00000` | 1MB | TRNG_BASE - True Random Number Generator |
| `0x45D00000` | 1MB | ABB_BASE - Analog Baseband |

### Common System Controllers

| Address | Size | Description |
|---------|------|-------------|
| `0x46000000` | 64KB | CMN_SYSCTRL_BASE - Common System Control |
| `0x46010000` | 64KB | CMN_ANACORE_BASE - Common Analog Core |
| `0x46020000` | 64KB | CMN_SYSPLL_CTRL_BASE - System PLL Control |
| `0x46030000` | 64KB | CMN_AUDPLL_CTRL_BASE - Audio PLL Control |
| `0x46100000` | 1MB | CMN_MAILBOX_BASE - Inter-processor Mailbox |
| `0x46200000` | 1MB | CMN_IOMUX_BASE - Common I/O Multiplexer |
| `0x46300000` | 1MB | CMN_UART_BASE - Common UART (UART3) |
| `0x46400000` | 1MB | CMN_FLASHC_BASE - Flash Controller |

### Always-On (AON) Peripherals

| Address | Size | Description |
|---------|------|-------------|
| `0x46800000` | 1MB | AON_PMUCTRL_BASE - Power Management Unit |
| `0x46810000` | 1MB | AON_AON_BASE - Always-On Controller |
| `0x46900000` | 1MB | AON_KEYSENSE_BASE - Key Sensing Controller |
| `0x46A00000` | 1MB | AON_CBUTTON_BASE - Capacitive Button Controller |
| `0x46B00000` | 1MB | AON_IWDT_BASE - Independent Watchdog |
| `0x46B00000` | 1MB | AON_TIMER_BASE - AON Timer *(overlaps IWDT)* |
| `0x46C00000` | 1MB | AON_RTC_BASE - Real-Time Clock |
| `0x46D00000` | 1MB | AON_EFUSECTRL_BASE - AON eFuse Controller |
| `0x46E00000` | 1MB | AON_VAD_BASE - Voice Activity Detection |
| `0x46E20000` | 13×64B | AON_CODEC_BASE - AON Audio Codec |
| `0x46F00000` | 1MB | AON_IOMUX_BASE - AON I/O Multiplexer |

### Shared Controllers

| Address | Size | Description |
|---------|------|-------------|
| `0x4A030000` | 64KB | CMN_PSRAMC_BASE - PSRAM Controller |
| `0x4A050000` | 64KB | CMN_DVP_BASE - Digital Video Port |

## HIFI4 DSP (CP) ADDITIONAL MEMORY MAP

### HiFi4 Specific Memory Regions

| Address | Size | Description |
|---------|------|-------------|
| `0x5FDE0000` | 128KB | DATA_RAM0_BASE - HiFi4 Data RAM 0 |
| `0x5FE00000` | 1MB | DATA_RAM1_BASE - HiFi4 Data RAM 1 |
| `0x5FF10000` | 128KB | INST_RAM0_BASE - HiFi4 Instruction RAM |

### Audio Processing Core

| Address | Size | Description |
|---------|------|-------------|
| `0x49000000` | 1MB | APC_BASE - Audio Processing Core (DMA Engine) |
| `0x49100000` | 1MB | CP_CODEC_BASE - HiFi4 Audio Codec (PDM2PCM) |
| `0x49200000` | 1MB | VAD_REG_BASE - Voice Activity Detection Registers |
| `0x49300000` | 1MB | VAD_RAM_BASE - Voice Activity Detection RAM |

### HiFi4 System Control

| Address | Size | Description |
|---------|------|-------------|
| `0x4A000000` | 64KB | CP_CFG_BASE - HiFi4 Configuration |
| `0x4A010000` | 64KB | CP_WATCHDOG_BASE - HiFi4 Watchdog |
| `0x4A020000` | 64KB | CP_DUALTIMER_BASE - HiFi4 Dual Timer |
| `0x4A040000` | 64KB | CP_UART_LOG_BASE - HiFi4 UART Logging |
| `0x4A050000` | 64KB | CP_DVP_BASE - HiFi4 Digital Video Port |
| `0x4A100000` | 1MB | NPU_CFG_BASE - Neural Processing Unit Config |
| `0x4A200000` | 1MB | DMAC_BASE - HiFi4 DMA Controller |

## AUDIO PROCESSING OFFSETS
*Relative to APC_BASE (0x49000000)*

### APC Transmit (Output) Channels

| Offset | Description |
|--------|-------------|
| `0x100` | APC_TX_CH0L_DATA_OFFSET - Left channel 0 output |
| `0x104` | APC_TX_CH0R_DATA_OFFSET - Right channel 0 output |
| `0x108` | APC_TX_CH1L_DATA_OFFSET - Left channel 1 output |
| `0x10C` | APC_TX_CH1R_DATA_OFFSET - Right channel 1 output |

### APC Receive (Input) Channels

| Offset | Description |
|--------|-------------|
| `0x110` | APC_RX_CH0L_DATA_OFFSET - Left channel 0 input |
| `0x114` | APC_RX_CH0R_DATA_OFFSET - Right channel 0 input |
| `0x118` | APC_RX_CH1L_DATA_OFFSET - Left channel 1 input |
| `0x11C` | APC_RX_CH1R_DATA_OFFSET - Right channel 1 input |
| `0x120` | APC_RX_CH2L_DATA_OFFSET - Left channel 2 input |
| `0x124` | APC_RX_CH2R_DATA_OFFSET - Right channel 2 input |

### APC Control Registers

| Offset | Description |
|--------|-------------|
| `0x20` | APC_TX_CH1_EQCOEF_BASE - Channel 1 EQ coefficients |
| `0x14C` | DAC_DATA_DUP_REG - DAC data duplication control |

## INTERRUPT VECTORS

### NVIC - CM33

| Vector | Description |
|--------|-------------|
| 15 | IRQ_CMN_MAILBOX_VECTOR - Inter-processor mailbox interrupt |
| 16 | IRQ_AP2CP_VECTOR - AP to CP combined interrupt (HiFi4) |

### XTENSA - HiFi4

| Vector | Description |
|--------|-------------|
| 10 | IRQ_MAILBOX_VECTOR - HiFi4 mailbox interrupt |
| 12 | IRQ_MAIN_VECTOR - HiFi4 main interrupt (sub-interrupt mux) |

## SPECIAL PURPOSE VALUES

### System Control Magic Values

| Value | Description |
|-------|-------------|
| `0xCAFE000B` | SYSCTRL_RESET_CP - Magic value to reset HiFi4 core |
| `0xCAFE100B` | SYSCTRL_RELEASE_CP - Magic value to release HiFi4 from reset |
| `0xCAFE000C` | SYSCTRL_RESET_NPU - Magic value to reset NPU |

### Hardware Lock Values

| Value | Description |
|-------|-------------|
| `0x5A5A` | MAILBOX_LOCK_MAGIC - Magic value for mailbox hardware mutex |

## PERIPHERAL INSTANCES
*Driver access mappings*

### Audio Codec Instances

| Instance | Base Address | Description |
|----------|--------------|-------------|
| CSK_ADC01 | AON_CODEC_BASE | ADC/PDM channels 0-1 (AON domain) |
| CSK_ADC23 | CP_CODEC_BASE | ADC/PDM channels 2-3 (CP domain) |
| CSK_DAC01 | CP_CODEC_BASE | DAC channels 0-1 (CP domain) |

### GPIO Instances

| Instance | Base Address | Description |
|----------|--------------|-------------|
| VENUS_GPIOA | GPIO0_BASE | GPIO Port A |
| VENUS_GPIOB | GPIO1_BASE | GPIO Port B |

### SPI Instances

| Instance | Base Address | Description |
|----------|--------------|-------------|
| CSK_SPI0 | SPI0_BASE | SPI Controller 0 |
| CSK_SPI1 | SPI1_BASE | SPI Controller 1 |

### Clock Control Offsets
*Relative to CMN_SYSCTRL_BASE (0x46000000)*

| Offset | Description |
|--------|-------------|
| `0x44` | CSK_SPI0_CLK_OFFSET - SPI0 clock control |
| `0x46` | CSK_SPI1_CLK_OFFSET - SPI1 clock control |

## IMPORTANT NOTES

1. **Asymmetric Memory Maps**: CM33 and HiFi4 see different address ranges for shared resources
2. **PSRAM/Flash Addressing**: Different base addresses when accessed from CM33 vs HiFi4  
3. **Address Overlaps**: Some AON peripherals overlap (IWDT/TIMER at 0x46B00000)
4. **Inter-Processor Communication**: Mailbox system provides primary communication channel
5. **Audio Processing**: Primarily handled by HiFi4 with APC DMA engine
6. **Physical Addresses**: All addresses are physical - no MMU translation involved
7. **Cache Coherency**: Requires explicit management via flush operations between cores

---
*Generated by: Claude Code Analysis*  
*Date: 2025-01-21*  
*Source: hal_listenai codebase drivers and register definitions*