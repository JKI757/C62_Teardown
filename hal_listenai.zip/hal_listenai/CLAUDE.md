# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is the Hardware Abstraction Layer (HAL) for the Listenai CSK6 SoC (System on Chip), specifically targeting the Venus platform. It provides low-level driver implementations for embedded firmware development on radio communication devices like the BK4819/RetevisC62.

## Architecture

The codebase is organized into two main processor cores:

### CM33 Core (Cortex-M33)
- **Location**: `csk6/drivers/cm33/`
- **Purpose**: Application processor with full peripheral driver support
- **Key Components**:
  - GPIO, UART, SPI, I2C, Timer drivers
  - Cryptographic engine support
  - Power management
  - Clock management
  - SDMMC/Flash storage interfaces
  - Audio codec interfaces (DVP, GPADC)

### HiFi4 Core (DSP)
- **Location**: `csk6/drivers/hifi4/`
- **Purpose**: Digital Signal Processor for audio/signal processing
- **Key Components**:
  - Audio processing (ADC/PDM, DAC)
  - DMA for high-throughput operations
  - Specialized audio codec drivers
  - Inter-processor communication (mailbox)

## Development Commands

### Build System
This project uses CMake and integrates with Zephyr RTOS:
```bash
# Configure build
cmake -B build
# Build project
cmake --build build
```

### Documentation Generation
API documentation is generated using Doxygen:
```bash
# Generate HTML documentation (already configured)
doxygen Doxyfile
# Documentation output: Documentation/html/index.html
```

The codebase contains 600+ documented API functions with full Doxygen comments.

### Memory Management
Custom heap management is provided via the CSK heap system:
- **Files**: `zephyr/heap/csk_malloc.c`, `zephyr/heap/csk_malloc.h`
- **API**: `csk_malloc()`, `csk_free()`, `csk_realloc()` functions

## Key Driver Categories

### Communication Interfaces
- **UART**: Multi-channel (UART0-3) with DMA support
- **SPI**: Master/slave modes with configurable parameters  
- **I2C**: Master mode support for peripheral communication

### Timing & PWM
- **GPT (General Purpose Timer)**: Multi-function timer with PWM/capture modes
- **Dual Timer**: Hardware timer implementation
- **AON Timer**: Always-on timer for low-power scenarios

### Power & Clock Management
- **ClockManager**: System and peripheral clock configuration
- **Power Control**: Low-power state management (HOLD, LIGHTSLEEP modes)
- **PSRAM Manager**: External PSRAM interface control

### Security
- **CRYPTO**: Hardware cryptographic acceleration
- **TRNG**: True Random Number Generator

### Audio Processing
- **GPADC**: General Purpose ADC for audio input
- **DAC**: Digital-to-Analog conversion for audio output
- **APC (Audio Processing Core)**: DSP audio processing

## File Organization

```
csk6/drivers/
├── cm33/               # Cortex-M33 drivers
│   ├── include/hal/    # Public header files
│   │   ├── Driver_*.h  # CMSIS-style driver interfaces
│   │   └── reg/        # Register definitions
│   └── *.c            # Driver implementations
├── hifi4/             # HiFi4 DSP drivers  
│   ├── include/hal/   # DSP-specific headers
│   └── *.c           # DSP driver implementations
└── CMakeLists.txt    # Build configuration

zephyr/
├── heap/             # Custom memory management
└── module.yml       # Zephyr module definition
```

## Hardware Register Access

Register definitions are organized by peripheral in `include/hal/reg/` directories:
- Venus-specific register layouts (`*_reg_venus.h`)
- Bit-field definitions for configuration registers
- Base addresses and interrupt vectors defined in platform headers

## Development Tips

### Driver Interface Pattern
All drivers follow CMSIS-Driver compatible interfaces with:
- Initialization functions (`CSK_*_Initialize`)
- Configuration functions (`CSK_*_Control`) 
- Data transfer functions (`CSK_*_Send`, `CSK_*_Receive`)
- Status query functions (`CSK_*_GetStatus`)

### Resource Management
- GPIO resources are statically allocated per port (GPIOA/GPIOB)
- DMA channels require explicit allocation before use
- Timer resources support multiple operation modes per instance

### Inter-Processor Communication
- Mailbox driver handles CM33 ↔ HiFi4 communication
- Shared memory regions defined in linker scripts
- Event-driven callback mechanisms for async operations

## Dual-Core Architecture: HiFi4 ↔ CM33 Communication

This HAL provides **complete dual-core support** for running both the Cortex-M33 application processor (AP) and the HiFi4 DSP co-processor (CP) simultaneously. The system includes everything needed to get both cores operational and communicating.

### Core Startup & Initialization

**CM33 (Application Processor)**:
- Primary boot core that starts first
- Handles system initialization, peripheral setup, and power management
- Controls HiFi4 core startup via PSRAM Manager (`csk6/drivers/cm33/PSRAMManger.c`)
- Reset/release sequence: `SYSCTRL_RESET_CP` → `SYSCTRL_RELEASE_CP`

**HiFi4 (DSP Co-Processor)**:
- Secondary core started by CM33 after system initialization
- Specialized for high-performance audio/signal processing
- Uses Xtensa RTOS primitives (XOS or XTOS) for interrupt handling
- Dedicated interrupt controller with sub-interrupt multiplexing

### Memory Architecture & Shared Resources

**PSRAM (External Memory)**:
- Shared between both cores for large data buffers
- CM33 manages PSRAM controller initialization and calibration
- DQS (Data Strobe) timing calibration for high-speed access
- Cache coherency maintained via explicit flush operations

**Shared Memory Regions**:
- Mailbox data registers: `REG_0X010-0X01C` (AP→CP), `REG_0X030-0X03C` (CP→AP)
- Each mailbox message carries 16 bytes (4 x 32-bit words)
- Hardware-enforced memory barriers prevent data corruption

### Mailbox Communication System

**Hardware Mailbox** (`cmn_mailbox_reg_venus.h`):
- **15 data channels** (0-14) for message passing
- **1 notification channel** (15) for acknowledgments
- **Bidirectional**: Separate AP and CP control/status registers
- **Interrupt-driven**: Hardware generates IRQs on message completion

**Communication Protocol**:
```c
// CM33 side (MBX_AP_WORK mode)
MBX_Send(NULL, data_buffer, channel);     // Send 16-byte message
MBX_Receive(NULL, rx_buffer, channel);   // Setup receive buffer

// HiFi4 side (MBX_CP_WORK mode)  
MBX_Send(NULL, data_buffer, channel);     // Send response
MBX_Receive(NULL, rx_buffer, channel);   // Setup receive buffer
```

**Lock Mechanism**:
- Hardware mutex using magic value `0x5A5A` for atomic operations
- Prevents race conditions during concurrent access
- Channel busy detection prevents message overwrites

### Audio Processing Pipeline

**HiFi4 Audio Drivers**:
- **ADC/PDM** (`adc_pdm_venus.c`): Dual-channel audio input (ADC01/ADC23)
  - Supports both analog (AMIC) and digital (DMIC) microphones
  - Configurable sample rates and bit depths
  - DMA integration via Audio Processing Core (APC)
  
- **DAC** (`dac_venus.c`): Audio output with stereo support
  - Left/Right channel independent control
  - Hardware echo cancellation support
  - Anti-pop and click reduction

**APC (Audio Processing Core)** (`apc_venus.c`):
- **8 DMA channels**: 4 input, 2 input/echo, 2 output
- **Hardware FIFO buffers**: Depth varies by channel
- **Multi-format support**: 16/24/32-bit samples, mono/stereo modes
- **Real-time processing**: Zero-copy DMA transfers

### Clock & Power Coordination

**Unified Clock Management**:
- Both cores share the same ClockManager interface
- HiFi4 can request clock changes via mailbox messages
- Audio PLLs managed centrally by CM33
- System/Audio PLL frequencies coordinated for both cores

**Power Management**:
- CM33 controls overall system power states
- HiFi4 can enter local low-power modes independently  
- PSRAM refresh maintained during HiFi4 sleep
- Wake-up coordination via interrupt system

### Interrupt Architecture

**CM33 Interrupts**:
- Standard NVIC with 32 interrupt vectors
- Mailbox IRQ: `IRQ_CMN_MAILBOX_VECTOR`
- Peripheral IRQs routed directly to CM33

**HiFi4 Interrupts**:
- Xtensa interrupt architecture (XOS/XTOS)
- Combined interrupt system: `IRQ_AP2CP_VECTOR` multiplexes 32 sub-interrupts
- Sub-interrupt dispatching in `venus_cp.c:ap2cp_isr()`
- Global interrupt enable/disable via `enable_GINT()/disable_GINT()`

### Development Workflow

**Dual-Core Development**:
1. **CM33 brings up system**: Initialize clocks, PSRAM, peripherals
2. **CM33 starts HiFi4**: Release HiFi4 from reset via PSRAM Manager
3. **Establish mailbox**: Both cores initialize mailbox drivers
4. **Audio pipeline setup**: HiFi4 configures ADC/DAC, CM33 handles I/O
5. **Runtime communication**: Asynchronous message passing for coordination

**Debugging Considerations**:
- Each core has independent debug interfaces
- Shared resource access requires careful timing analysis
- Memory coherency issues debugged via cache flush points
- Mailbox message tracing via callback functions

**Boot Dependencies**:
- HiFi4 **cannot start independently** - requires CM33 to initialize system
- All external memory (PSRAM) setup must be completed before HiFi4 boot
- Clock tree must be stable before releasing HiFi4 from reset

This HAL provides a **complete dual-core solution** with all necessary infrastructure for HiFi4-CM33 coordination, making it suitable for complex audio processing applications requiring both high-performance DSP and real-time system management.

## Peripheral Addresses
Hardware peripheral base addresses are documented in the `Peripheral_Addresses` file (excluded from version control).

## Dependencies
- Zephyr RTOS framework
- CMSIS (ARM Cortex Microcontroller Software Interface Standard)
- Hardware-specific Venus SoC register definitions